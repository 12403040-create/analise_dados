import matplotlib.pyplot as plt
import seaborn as sns

from dados import carregar_pop_estado
from grafico_utils import aplicar_formato_milhar, configurar_estilo, formatar_milhar, salvar_figura


def gerar_grafico():
    configurar_estilo()
    pop_estado = carregar_pop_estado()
    ordem = pop_estado.sort_values("2022", ascending=False)

    fig, ax = plt.subplots(figsize=(9, 8))
    sns.barplot(data=ordem, y="UF", x="2022", ax=ax, color="steelblue")
    ax.bar_label(
        ax.containers[0],
        labels=[formatar_milhar(v) for v in ax.containers[0].datavalues],
        padding=3,
        fontsize=8,
    )
    aplicar_formato_milhar(ax.xaxis)
    ax.set_title("População 2022 por UF")
    ax.set_xlabel("Habitantes")
    ax.set_ylabel("UF")
    ax.margins(x=0.1)
    plt.tight_layout()
    return salvar_figura(fig, "atividade4_populacao_2022_uf.png")


if __name__ == "__main__":
    print(gerar_grafico())

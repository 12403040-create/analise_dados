import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import FuncFormatter

from dados import PASTA_GRAFICOS

PALETA_SEXO = {"homens": "#2E6F9E", "mulheres": "#D9822B"}


def configurar_estilo():
    sns.set_theme(style="whitegrid", context="notebook")
    plt.rcParams["axes.spines.top"] = False
    plt.rcParams["axes.spines.right"] = False


def formatar_milhar(valor, _posicao=None):
    return f"{valor:,.0f}".replace(",", ".")


def aplicar_formato_milhar(eixo):
    eixo.set_major_formatter(FuncFormatter(formatar_milhar))


def salvar_figura(fig, nome_arquivo):
    PASTA_GRAFICOS.mkdir(parents=True, exist_ok=True)
    caminho = PASTA_GRAFICOS / nome_arquivo
    fig.savefig(caminho, dpi=200, bbox_inches="tight")
    if plt.get_backend().lower() != "agg":
        plt.show()
    plt.close(fig)
    return caminho

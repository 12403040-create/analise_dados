import atividade2
import atividade3
import atividade4


def main():
    for modulo in (atividade2, atividade3, atividade4):
        print(modulo.gerar_grafico())


if __name__ == "__main__":
    main()

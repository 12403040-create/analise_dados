from pathlib import Path

import pandas as pd

PASTA_DADOS = Path(__file__).resolve().parent.parent / "dados"
PASTA_GRAFICOS = Path(__file__).resolve().parent.parent / "graficos"

REGIOES = ["Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"]


def carregar_indicador_1():
    return pd.read_csv(PASTA_DADOS / "indicador_1.csv")


def carregar_formacao_total():
    return pd.read_csv(PASTA_DADOS / "formacao_total.csv")


def carregar_formacao_stem():
    return pd.read_csv(PASTA_DADOS / "formacao_stem.csv")


def carregar_formacao_saude():
    return pd.read_csv(PASTA_DADOS / "formacao_saude.csv")


def carregar_pop_estado():
    return pd.read_csv(PASTA_DADOS / "pop_estado.csv")

import matplotlib.pyplot as plt
import seaborn as sns

from dados import REGIOES, carregar_indicador_1
from grafico_utils import PALETA_SEXO, configurar_estilo, salvar_figura


def preparar_dados(indicador_1):
    reg = indicador_1[indicador_1["uf_regiao"].isin(REGIOES)].copy()
    reg["homens"] = (reg["homem_branca"] + reg["homem_preta_parda"]) / 2
    reg["mulheres"] = (reg["mulher_branca"] + reg["mulher_preta_parda"]) / 2
    reg["uf_regiao"] = reg["uf_regiao"].astype("category").cat.set_categories(REGIOES, ordered=True)
    reg = reg.sort_values("uf_regiao")
    reg_long = reg.melt(
        id_vars="uf_regiao",
        value_vars=["homens", "mulheres"],
        var_name="sexo",
        value_name="horas",
    )
    return reg_long


def gerar_grafico():
    configurar_estilo()
    indicador_1 = carregar_indicador_1()
    reg_long = preparar_dados(indicador_1)

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(
        data=reg_long,
        x="uf_regiao",
        y="horas",
        hue="sexo",
        palette=PALETA_SEXO,
        ax=ax,
    )
    for container in ax.containers:
        ax.bar_label(container, fmt="%.1f", padding=3, fontsize=9)
    ax.set_title("Afazeres domésticos por região e sexo")
    ax.set_xlabel("Região")
    ax.set_ylabel("Horas / semana")
    ax.legend(title="Sexo", loc="upper left", bbox_to_anchor=(1.01, 1), frameon=False)
    ax.margins(y=0.12)
    plt.tight_layout()
    return salvar_figura(fig, "atividade2_afazeres_domesticos_regiao_sexo.png")


if __name__ == "__main__":
    print(gerar_grafico())

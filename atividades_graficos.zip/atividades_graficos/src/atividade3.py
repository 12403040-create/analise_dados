import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from dados import (
    carregar_formacao_saude,
    carregar_formacao_stem,
    carregar_formacao_total,
)
from grafico_utils import (
    PALETA_SEXO,
    aplicar_formato_milhar,
    configurar_estilo,
    formatar_milhar,
    salvar_figura,
)


def preparar_dados(formacao_total, formacao_stem, formacao_saude):
    brasil = pd.DataFrame(
        {
            "area": ["Graduação (total)", "STEM", "Saúde / educação"],
            "homens": [
                formacao_total.loc[formacao_total["uf_regiao"] == "Brasil", "total_homens"].item(),
                formacao_stem.loc[formacao_stem["uf_regiao"] == "Brasil", "homens"].item(),
                formacao_saude.loc[formacao_saude["uf_regiao"] == "Brasil", "homens"].item(),
            ],
            "mulheres": [
                formacao_total.loc[formacao_total["uf_regiao"] == "Brasil", "total_mulheres"].item(),
                formacao_stem.loc[formacao_stem["uf_regiao"] == "Brasil", "mulheres"].item(),
                formacao_saude.loc[formacao_saude["uf_regiao"] == "Brasil", "mulheres"].item(),
            ],
        }
    )
    return brasil.melt(id_vars="area", var_name="sexo", value_name="pessoas")


def gerar_grafico():
    configurar_estilo()
    brasil_long = preparar_dados(
        carregar_formacao_total(),
        carregar_formacao_stem(),
        carregar_formacao_saude(),
    )

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(
        data=brasil_long,
        x="area",
        y="pessoas",
        hue="sexo",
        palette=PALETA_SEXO,
        ax=ax,
    )
    for container in ax.containers:
        ax.bar_label(container, labels=[formatar_milhar(v) for v in container.datavalues], padding=3, fontsize=9)
    aplicar_formato_milhar(ax.yaxis)
    ax.set_title("Brasil: pessoas com graduação, por área e sexo")
    ax.set_xlabel("Área")
    ax.set_ylabel("Pessoas")
    ax.legend(title="Sexo", loc="upper left", bbox_to_anchor=(1.01, 1), frameon=False)
    ax.margins(y=0.12)
    plt.tight_layout()
    return salvar_figura(fig, "atividade3_formacao_brasil_area_sexo.png")


if __name__ == "__main__":
    print(gerar_grafico())

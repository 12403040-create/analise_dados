# Gráficos – Atividades 2, 3 e 4

## Estrutura

```
atividades_graficos/
├── dados/        CSVs de entrada
├── graficos/     PNGs gerados
├── src/
│   ├── dados.py
│   ├── grafico_utils.py
│   ├── atividade2.py
│   ├── atividade3.py
│   ├── atividade4.py
│   └── main.py
└── requirements.txt
```

## Como executar

```
pip install -r requirements.txt
python src/main.py
```

Cada atividade também roda sozinha: `python src/atividade2.py`.

## Atenção: dados de exemplo

Os CSVs em `dados/` são **exemplos** com a mesma estrutura de colunas do enunciado,
para que o projeto rode de ponta a ponta. Os valores das atividades 2 e 3 são
fictícios. Substitua cada arquivo pelos seus dados reais mantendo os nomes das colunas.

| Arquivo | Atividade | Colunas esperadas |
|---|---|---|
| `indicador_1.csv` | 2 | `uf_regiao`, `homem_branca`, `homem_preta_parda`, `mulher_branca`, `mulher_preta_parda` |
| `formacao_total.csv` | 3 | `uf_regiao`, `total_homens`, `total_mulheres` |
| `formacao_stem.csv` | 3 | `uf_regiao`, `homens`, `mulheres` |
| `formacao_saude.csv` | 3 | `uf_regiao`, `homens`, `mulheres` |
| `pop_estado.csv` | 4 | `UF`, `2022` |

Se seus dados estiverem em Excel, troque `pd.read_csv` por `pd.read_excel` em `src/dados.py`.
Se os nomes das regiões forem diferentes, ajuste a lista `REGIOES` no mesmo arquivo.

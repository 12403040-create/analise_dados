# Atividade Aula 2 — Desocupação por sexo (2012 T1 x 2026 T1)

## Conteúdo da pasta
- `atividade_aula2.py` — código comentado (rode na mesma pasta dos CSVs)
- `Tabela5-sem_emprego_2012.csv` e `Tabela5-sem_emprego_2026.csv` — dados
- `grafico_desocupacao_mulheres.png` — gráfico gerado

## Como rodar
```
python atividade_aula2.py
```
Bibliotecas: pandas, matplotlib, seaborn (se faltar: `python -m pip install pandas matplotlib seaborn`).

## Resumo para a prova

| Etapa | Comando | Para que serve |
|---|---|---|
| Ler CSV | `pd.read_csv(..., sep=";", decimal=",", encoding="utf-8-sig")` | separador `;`, decimal com vírgula, remove BOM |
| Renomear | `df.columns = [...]` | nomes curtos e únicos por ano |
| Juntar | `t2012.merge(t2026, on=["Sigla","Código","Estado"], how="inner")` | une as tabelas pelas colunas-chave |
| Ordenar | `comp.sort_values("mulheres_2026", ascending=False)["Estado"]` | define a ordem das barras |
| Derreter | `comp.melt(id_vars=..., value_vars=..., var_name=..., value_name=...)` | formato largo -> formato longo |
| Figura | `fig, ax = plt.subplots(figsize=(10, 10))` | cria figura e eixo |
| Barras | `sns.barplot(data, y, x, hue, order, ax)` | `hue` cria a comparação entre anos |
| Linha | `ax.axvline(50, ...)` | linha de paridade (50%) |
| Mostrar | `plt.show()` | exibe o gráfico |

## Ideias-chave
- **merge** junta colunas de tabelas diferentes (lado a lado); **melt** muda o formato de UMA tabela (largo -> longo).
- `id_vars` = colunas que ficam fixas; `value_vars` = colunas que viram linhas.
- O seaborn precisa do formato longo para usar `hue`.

## Resultados
- Mulheres eram maioria entre desocupados em 23 de 27 estados em 2012 T1 e em 22 de 27 em 2026 T1.
- Maiores altas (pontos percentuais): Rondônia +10,4; Tocantins +9,1; Sergipe +6,2.
- Maiores quedas: Acre -7,9; Distrito Federal -6,9; Goiás -6,5.

## Pendente
A parte da **Tabela 1.1.1 (IBGE, horas semanais de cuidados e afazeres domésticos, 2022)** e o código original da Aula 2 não foram enviados. Com esses arquivos, o cruzamento com as horas de cuidados pode ser adicionado ao script.

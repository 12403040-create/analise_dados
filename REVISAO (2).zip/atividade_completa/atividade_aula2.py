import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ---------------------------------------------------------------
# 1) ABRIR AS DUAS TABELAS 5
# ---------------------------------------------------------------
# sep=";"          -> o CSV usa ponto e vírgula como separador
# decimal=","      -> os números usam vírgula (45,3) e não ponto (45.3)
# encoding="utf-8-sig" -> remove o "BOM" invisível no começo do arquivo
t2012 = pd.read_csv("Tabela5-sem_emprego_2012.csv", sep=";", decimal=",", encoding="utf-8-sig")
t2026 = pd.read_csv("Tabela5-sem_emprego_2026.csv", sep=";", decimal=",", encoding="utf-8-sig")

# Nomes de coluna curtos (os originais são enormes e diferentes entre os anos)
t2012.columns = ["Sigla", "Código", "Estado", "homens_2012", "mulheres_2012"]
t2026.columns = ["Sigla", "Código", "Estado", "homens_2026", "mulheres_2026"]

# ---------------------------------------------------------------
# 2) JUNTAR AS TABELAS (MERGE)
# ---------------------------------------------------------------
# on=[...]   -> colunas que identificam o MESMO estado nas duas tabelas
# how="inner"-> fica só com estados presentes nas duas
comp = t2012.merge(t2026, on=["Sigla", "Código", "Estado"], how="inner")

# Variação em pontos percentuais da participação feminina
comp["variacao_mulheres_pp"] = comp["mulheres_2026"] - comp["mulheres_2012"]

print(comp.head())
print(comp.shape)

# ---------------------------------------------------------------
# 3) PREPARAR PARA O GRÁFICO
# ---------------------------------------------------------------
# sort_values ordena o DataFrame; pegamos só a coluna "Estado".
# Essa lista define a ORDEM das barras no eixo Y.
ordem = comp.sort_values("mulheres_2026", ascending=False)["Estado"]

# melt() "derrete" o DataFrame: de formato LARGO (uma coluna por ano)
# para formato LONGO (uma coluna "Ano" + uma coluna com o valor).
# O seaborn precisa do formato longo para usar hue="Ano".
longo = comp.melt(
    id_vars=["Sigla", "Código", "Estado"],          # ficam como estão
    value_vars=["mulheres_2012", "mulheres_2026"],  # viram linhas
    var_name="Ano",
    value_name="Participacao_mulheres",
)
longo["Ano"] = longo["Ano"].map({"mulheres_2012": "2012 T1", "mulheres_2026": "2026 T1"})

# ---------------------------------------------------------------
# 4) GRÁFICO
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(10, 10))      # cria a figura (largura, altura)
sns.barplot(
    data=longo,
    y="Estado",
    x="Participacao_mulheres",
    hue="Ano",
    order=ordem,
    ax=ax,
)
ax.axvline(50, color="red", linestyle="--", linewidth=1)  # linha de paridade (50%)
ax.set_xlabel("Participação das mulheres entre as pessoas desocupadas (%)")
ax.set_ylabel("")
ax.set_title("Desocupação: participação feminina em 2012 T1 e 2026 T1")
ax.legend(title="Trimestre")
fig.tight_layout()
fig.savefig("grafico_desocupacao_mulheres.png", dpi=150)
plt.show()

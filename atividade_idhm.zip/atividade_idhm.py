import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Tabela4.csv", sep=";", decimal=",", encoding="cp1252", skiprows=1)
print(df.head())
print(df.shape)

df = df.dropna(axis=1, how="all")
df = df.dropna(axis=0, how="all")
df.columns = [str(c).strip() for c in df.columns]
print(df.columns.tolist())

ranking_2024 = df.sort_values("2024", ascending=False)[["Sigla", "Estado", "2024"]].reset_index(drop=True)
ranking_2024.index = ranking_2024.index + 1
print(ranking_2024)

df["Melhora_1991_2024"] = df["2024"] - df["1991"]
maior = df.loc[df["Melhora_1991_2024"].idxmax()]
print(f"Maior melhora entre 1991 e 2024: {maior['Estado']} ({maior['Sigla']}) com {maior['Melhora_1991_2024']:.3f} pontos")
print(df.sort_values("Melhora_1991_2024", ascending=False)[["Sigla", "Estado", "1991", "2024", "Melhora_1991_2024"]].head(5))

pioraram = df[df["Melhora_1991_2024"] < 0][["Sigla", "Estado", "1991", "2024"]]
if pioraram.empty:
    print("Nenhum estado teve IDH pior em 2024 do que em 1991")
else:
    print(pioraram)

anos = [c for c in df.columns if str(c).isdigit()]
print(anos)

id_vars = [c for c in df.columns if c not in anos and c != "Melhora_1991_2024"]
df_longo = df.melt(
    id_vars=id_vars,
    value_vars=anos,
    var_name="Ano",
    value_name="IDH",
)
df_longo["Ano"] = df_longo["Ano"].astype(int)
df_longo["IDH"] = pd.to_numeric(df_longo["IDH"], errors="coerce")
print(df_longo.head())

df_longo = df_longo.sort_values(["Sigla", "Ano"])
df_longo["Variacao"] = df_longo.groupby("Sigla")["IDH"].diff()
quedas = df_longo[df_longo["Variacao"] < 0]
print(quedas.groupby("Ano")["Sigla"].count())

mg = df_longo[df_longo["Sigla"] == "MG"].sort_values("Ano")
fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(mg["Ano"], mg["IDH"], marker="o", markersize=4, linewidth=2, color="tab:blue", label="MG")
ax.set_title("Evolução do IDH em Minas Gerais (1991–2024)")
ax.set_xlabel("Ano")
ax.set_ylabel("IDH")
ax.set_ylim(0.3, 0.9)
ax.grid(True, alpha=0.3)
ax.legend(title="UF")
fig.tight_layout()
fig.savefig("grafico_minas_gerais.png", dpi=150)
plt.show()

fig, ax = plt.subplots(figsize=(12, 7))
for sigla, grupo in df_longo.groupby("Sigla"):
    grupo = grupo.sort_values("Ano")
    ax.plot(grupo["Ano"], grupo["IDH"], marker="o", markersize=3, linewidth=1.5, label=sigla)

ax.set_title("Evolução do IDH por estado (1991–2024)")
ax.set_xlabel("Ano")
ax.set_ylabel("IDH")
ax.set_ylim(0.3, 0.9)
ax.legend(ncol=3, bbox_to_anchor=(1.02, 1), loc="upper left", title="UF")
fig.tight_layout()
fig.savefig("grafico_todos_estados.png", dpi=150)
plt.show()
